package com.ParallelProjectTest.Exception;

public class WalletException extends Exception {

	public WalletException(String message) {
		super(message);
	}

	public WalletException() {
		super();
	}

}
