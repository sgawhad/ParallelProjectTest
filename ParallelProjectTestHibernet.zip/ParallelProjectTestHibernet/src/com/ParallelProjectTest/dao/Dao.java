package com.ParallelProjectTest.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.ParallelProjectTest.Exception.BalanceException;
import com.ParallelProjectTest.Exception.WalletException;
import com.ParallelProjectTest.bean.CustomerBean;
import com.ParallelProjectTest.bean.TransactionsSummary;

public class Dao implements IDao {

	static Map<Integer, CustomerBean> detiMap = new HashMap<Integer, CustomerBean>();

	static Map<Integer, Double> balMap = new HashMap<Integer, Double>();

	Transaction[] txns = new Transaction[10];
	int idx;

	private EntityManager em;

	public Dao() {

		em = JPAUtil.getEntityManager();
		em.getTransaction().begin();
	}

	@Override
	public CustomerBean creatAccount(int acntNo, String name, String mobile,
			String email) throws WalletException, SQLException {
		try {
			em.getTransaction().begin();

			CustomerBean cust = new CustomerBean(acntNo, name,
					Long.parseLong(mobile), email);

			em.persist(cust);

			TransactionsSummary trns = new TransactionsSummary(0, 0, "IB", cust);

			em.persist(trns);

			em.getTransaction().commit();

			System.out.println("Customer added to database.");

			return em.find(CustomerBean.class, (acntNo));
		} catch (NumberFormatException e) {
		} finally {
		}
		return null;

	}

	@Override
	public boolean logIn(String acntNo) throws NumberFormatException,
			SQLException {

		CustomerBean cust = em.find(CustomerBean.class,
				Integer.parseInt(acntNo));
		if (cust == null) {
			return false;
		}
		return true;

	}

	@Override
	public Double showBalance(String acntNo) throws NumberFormatException,
			SQLException {
		CustomerBean bal = em
				.find(CustomerBean.class, Integer.parseInt(acntNo));
		return bal.getBalance();

	}

	@Override
	public void deposit(String acntNo, String amount)
			throws NumberFormatException, SQLException {

		em.getTransaction().begin();

		CustomerBean bal = em
				.find(CustomerBean.class, Integer.parseInt(acntNo));
		double balance = bal.getBalance() + Double.parseDouble(amount);
		bal.setBalance(balance);
		em.merge(bal);
		TransactionsSummary trns = new TransactionsSummary(
				Integer.parseInt(amount), balance, "CR", bal);
		em.persist(trns);

		em.getTransaction().commit();

	}

	@Override
	public void withdraw(String acntNo, String amount) throws BalanceException,
			NumberFormatException, SQLException {

		CustomerBean bal = em
				.find(CustomerBean.class, Integer.parseInt(acntNo));

		if (bal.getBalance() > Double.parseDouble(amount)) {
			em.getTransaction().begin();
			double balance = bal.getBalance() - Double.parseDouble(amount);
			bal.setBalance(balance);
			em.merge(bal);
			TransactionsSummary trns = new TransactionsSummary(
					Integer.parseInt(amount), balance, "WR", bal);
			em.persist(trns);

			em.getTransaction().commit();

		} else {
			System.out
					.println("You have insufficient balance. Please add money first");
		}
	}

	@Override
	public void fundTransfer(String sendAccNo, String recAcntNo, String amount)
			throws BalanceException, NumberFormatException, SQLException {

		CustomerBean balRec = em.find(CustomerBean.class,
				Integer.parseInt(recAcntNo));
		if (balRec == null) {
			System.out.println("Receiver not found");
		}
		CustomerBean balSender = em.find(CustomerBean.class,
				Integer.parseInt(sendAccNo));

		if (balSender.getBalance() > Double.parseDouble(amount)) {
			em.getTransaction().begin();

			double balanceSender = balSender.getBalance()
					- Double.parseDouble(amount);
			balSender.setBalance(balanceSender);
			em.merge(balSender);
			TransactionsSummary trnsSend = new TransactionsSummary(
					Double.parseDouble(amount), balanceSender, "FT", balSender);
			em.persist(trnsSend);

			double balanceReceiver = balRec.getBalance()
					+ Double.parseDouble(amount);
			balRec.setBalance(balanceReceiver);
			em.merge(balRec);
			TransactionsSummary trnsRec = new TransactionsSummary(
					Double.parseDouble(amount), balanceReceiver, "FT", balRec);
			em.persist(trnsRec);
			em.getTransaction().commit();

		} else {
			System.out.println("Insufficent balance");
		}

	}

	// @Override
	/*
	 * public List<TransactionsSummary> printTransaction(String acntNo) { int
	 * acno = Integer.parseInt(acntNo); String qStr =
	 * "SELECT transum FROM TransactionsSummary transum WHERE transum.id=acno";
	 * TypedQuery<TransactionsSummary> query = em.createQuery(qStr,
	 * TransactionsSummary.class); query.setParameter("acountNumber", acno);
	 * List<TransactionsSummary> bookList = query.getResultList(); return
	 * bookList; }
	 * 
	 * Query query = em.createNamedQuery("getAllTransactions");
	 * 
	 * @SuppressWarnings("unchecked") List<TransactionsSummary> bookList =
	 * query.getResultList(); return bookList;
	 */

	/**
	 * String qStr = "SELECT book FROM Book book WHERE book.author=:pAuthor";
	 * TypedQuery<Book> query = entityManager.createQuery(qStr, Book.class);
	 * query.setParameter("pAuthor", author); List<Book> bookList
	 * =query.getResultList(); return bookList;
	 */
	@Override
	public List<TransactionsSummary> printTransaction(String acntNo) {

		String qStr = "SELECT trans FROM TransactionsSummary trans WHERE trans.customer.id=:pSrNo order by sr_no";
		TypedQuery<TransactionsSummary> query = em.createQuery(qStr,
				TransactionsSummary.class);
		query.setParameter("pSrNo", Integer.parseInt(acntNo));

		List<TransactionsSummary> transactions = query.getResultList();

		return transactions;

	}

	@Override
	public CustomerBean showDetails(int acntNo) {
		return detiMap.get(acntNo);
	}

}
