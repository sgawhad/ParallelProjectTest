package com.ParallelProjectTest.dao;

import java.sql.SQLException;

import com.ParallelProjectTest.Exception.WalletException;

public interface IDaoSql {

	

	void storeIntoTable(String name, String mobile, String email, int acntNo)
			throws WalletException, SQLException;

}
