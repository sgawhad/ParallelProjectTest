package com.ParallelProjectTest.dao;

public interface QuaryMapper {

	String insertDetails = "insert into bankUserDetails "
			+ "(CUSTOMERID,  NAME, MOBILE,"
			+ "  ADDRESS, EMAIL)  values (?,?,?,?,?)";

	// String selectDetails = "select * from bankUserDetails ";

	String selectDetails = "select * from bankUserDetails where customerid = ?";

	String select = "select * from bankUserDetails where CUSTOMERID =?";
	
	String updateBalance = "update bankuserdetails set  balance = ? where customerid= ?";
	
	String sql = "insert into bankUserDetails values(?,?,?,?,?)";

}