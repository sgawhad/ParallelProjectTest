package com.ParallelProjectTest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import oracle.net.aso.q;

import com.ParallelProjectTest.Exception.WalletException;
import com.ParallelProjectTest.bean.CustomerBean;
import com.ParallelProjectTest.utility.JdbcFactory;
import com.ParallelProjectTest.utility.JdbcUtil;

public class DaoSql implements IDaoSql {

	Connection connection = null;

	@Override
	public void storeIntoTable(String name, String mobile, String email,
			int acntNo) throws WalletException, SQLException {

		try {
			connection = JdbcFactory.getConnection();
			PreparedStatement stmt = connection.prepareStatement(QuaryMapper.sql);
			stmt.setInt(1, acntNo);
			stmt.setString(2, name);
			stmt.setString(3, mobile);
			stmt.setString(4, email);
			stmt.setDouble(5, 0);
			
			stmt.executeUpdate();
			System.out.println("Record Inserted");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
	
	public void updateBalance (int acntNo, double balance) throws SQLException{
		
		try {
			connection = JdbcFactory.getConnection();
			PreparedStatement stmt = connection.prepareStatement(QuaryMapper.updateBalance);
			stmt.setDouble(1, balance);
			stmt.setInt(2, acntNo);
			
			stmt.executeUpdate();
			System.out.println("Balance updated in database");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
		
		
		
	}
	
	

}