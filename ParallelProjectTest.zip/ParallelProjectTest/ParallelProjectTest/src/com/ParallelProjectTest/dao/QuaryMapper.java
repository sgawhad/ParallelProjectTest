package com.ParallelProjectTest.dao;

public interface QuaryMapper {

	String insertDetails = "insert into bankUserDetails "
			+ "(CUSTOMERID,  NAME, MOBILE,"
			+ "  ADDRESS, EMAIL)  values (?,?,?,?,?)";

	// String selectDetails = "select * from bankUserDetails ";

	String selectDetails = "select Name from bankUserDetails";

	String select = "select * from bankUserDetails where CUSTOMERID =?";

}