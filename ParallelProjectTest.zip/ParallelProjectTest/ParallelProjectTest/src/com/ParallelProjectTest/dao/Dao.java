package com.ParallelProjectTest.dao;

import java.util.HashMap;
import java.util.Map;

import com.ParallelProjectTest.bean.CustomerBean;
import com.ParallelProjectTest.bean.TransactionsSummary;

public class Dao implements IDao {

	static Map<Integer, CustomerBean> detiMap = new HashMap<Integer, CustomerBean>();

	static Map<Integer, Double> balMap = new HashMap<Integer, Double>();

	TransactionsSummary[] txns = new TransactionsSummary[10];

	static int acntNo = (int) (Math.random() * 1000);
	
	static int idx;

	@Override
	public void creatAccount(String name, String mobile, String email) {

		CustomerBean cust = new CustomerBean(name, Long.parseLong(mobile),
				email);

		

		cust.setAcntNo(acntNo);

		detiMap.put(acntNo, cust);

		balMap.put(acntNo, 0.0); // As initial balance is zero

		System.out.println(detiMap.get(acntNo));

//		txns = new TransactionsSummary[10];
		
		

	}

	@Override
	public boolean logIn(String acntNo) {

		if (detiMap.containsKey(Integer.parseInt(acntNo)))
			return true;
		return false;

	}

	@Override
	public Double showBalance(String acntNo) {
		return balMap.get(Integer.parseInt(acntNo));
	}

	@Override
	public void deposit(String acntNo, String amount) {
		balMap.put(
				Integer.parseInt(acntNo),
				balMap.get(Integer.parseInt(acntNo))
						+ Double.parseDouble(amount));
		txns[idx++] = new TransactionsSummary("CR", Double.parseDouble(amount),
				balMap.get(Integer.parseInt(acntNo)));

	}

	@Override
	public void withdraw(String acntNo, String amount) {
		if (Double.parseDouble(amount) <= balMap.get(Integer.parseInt(acntNo))) {
			balMap.put(Integer.parseInt(acntNo), (balMap.get(Integer
					.parseInt(acntNo)) - Double.parseDouble(amount)));
			System.out.println(amount + " withdraw from your account");
			txns[idx++] = new TransactionsSummary("WR",
					Double.parseDouble(amount), balMap.get(Integer
							.parseInt(acntNo)));

		} else {
			System.out
					.println("You have insufficient balance. Please add money first");
		}
	}

	@Override
	public void fundTransfer(String sendAccNo, String recAcntNo, String amount) {
		if (balMap.containsKey(Integer.parseInt(recAcntNo))) {
			if (Double.parseDouble(amount) <= balMap.get(Integer
					.parseInt(sendAccNo))) {
				balMap.put(
						Integer.parseInt(sendAccNo),
						balMap.get(Integer.parseInt(sendAccNo))
								- Double.parseDouble(amount));
				balMap.put(
						Integer.parseInt(recAcntNo),
						balMap.get(Integer.parseInt(recAcntNo))
								+ Double.parseDouble(amount));
				txns[idx++] = new TransactionsSummary("FT",
						Double.parseDouble(amount), balMap.get(Integer
								.parseInt(sendAccNo)));
				System.out.println(amount + " Transfer done ");
			}

		} else
			System.out
					.println("Receiver not found \nPlease enter valid details");
	}

	@Override
	public void printTransaction() {
		System.out.println("Type\tAmount\tBalance");
		for (int i = 0; i < idx; i++)
			System.out.println(txns[i].print());

	}

	@Override
	public CustomerBean customerDetails(String acntNo) {
		
		return 		detiMap.get(Integer.parseInt(acntNo));
	}

}
