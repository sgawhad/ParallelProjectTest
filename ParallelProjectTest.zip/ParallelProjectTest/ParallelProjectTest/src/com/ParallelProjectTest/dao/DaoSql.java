package com.ParallelProjectTest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ParallelProjectTest.Exception.WalletException;
import com.ParallelProjectTest.bean.CustomerBean;
import com.ParallelProjectTest.utility.JdbcUtil;

public class DaoSql implements IDaoSql {

	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public void storeIntoTable(String name, String mobile, String email) throws WalletException, SQLException {
		
		CustomerBean cust = new CustomerBean(name, Long.parseLong(mobile), email);
		cust.setAcntNo(Dao.acntNo);
		
		connection= JdbcUtil.getConnection();
		
		statement=connection.prepareStatement(QuaryMapper.insertDetails);
		statement.setInt(1, cust.getAcntNo());
		statement.setString(2, cust.getName());
		statement.setLong(3, cust.getMobile());
		statement.setString(4, cust.getEmail());

		statement.executeUpdate();
		
		
		
	}

}