package com.ParallelProjectTest.dao;

import java.sql.SQLException;

import com.ParallelProjectTest.Exception.WalletException;
import com.ParallelProjectTest.bean.CustomerBean;

public interface IDaoSql {

		void storeIntoTable(String name, String mobile, String email ) throws WalletException, SQLException;
		
		
		
}
