package com.ParallelProjectTest.bean;

public class TransactionsSummary {

	private double amount, balance;
	private String type;

	public TransactionsSummary() {
	}

	public TransactionsSummary(String type, double amount, double balance) {
		super();
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return type + "\t" + amount + "\t" + balance;
	}

	public String print() {

		return type + "\t" + amount + "\t" + balance;
	}

}
