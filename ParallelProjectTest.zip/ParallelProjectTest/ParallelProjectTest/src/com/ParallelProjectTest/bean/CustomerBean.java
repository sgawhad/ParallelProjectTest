package com.ParallelProjectTest.bean;

public class CustomerBean {

	private int acntNo; // auto generated
	private String name;
	private long mobile;
	private String email;
	

	public int getAcntNo() {
		return acntNo;
	}

	public void setAcntNo(int acntNo) {
		this.acntNo = acntNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public CustomerBean(String name, long mobile, String email) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
	}

	@Override
	public String toString() {
		return "Account No = " + acntNo + "\nName = " + name
				+ "\nMobile No = " + mobile + "\nEmail Id = " + email +"\n";
	}

}
