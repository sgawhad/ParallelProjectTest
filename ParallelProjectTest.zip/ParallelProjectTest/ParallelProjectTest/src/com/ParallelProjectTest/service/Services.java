package com.ParallelProjectTest.service;

import java.sql.SQLException;

import com.ParallelProjectTest.Exception.WalletException;
import com.ParallelProjectTest.bean.CustomerBean;
import com.ParallelProjectTest.dao.Dao;
import com.ParallelProjectTest.dao.DaoSql;

public class Services implements IService {
	Dao dao = new Dao();
	DaoSql daoSql = new DaoSql();

	@Override
	public boolean validateChoice(String choice) {
		if (choice.matches(choice))
			return true;
		return false;
	}

	@Override
	public boolean validateAcntNo(String acnNto) {
		if (acnNto.matches(ACC_NO))
			return true;

		return false;
	}

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(USER_NAME_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateMobileNo(String mobileNo) {
		if (mobileNo.matches(MOBILE_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(EMAIL_PATTERN))
			return true;
		return false;
	}

	@Override
	public boolean validateAmount(String amount) {
		if (amount.matches(AMOUNT))
			return true;
		return false;
	}

	@Override
	public void creatAccount(String name, String mobile, String email) {
		dao.creatAccount(name, mobile, email);
	}

	@Override
	public boolean logIn(String acntNo) {
		return dao.logIn(acntNo);

	}

	@Override
	public Double showBalance(String acntNo) {
		return dao.showBalance(acntNo);
	}

	@Override
	public void deposit(String acntNo, String amount) {
		dao.deposit(acntNo, amount);
	}

	@Override
	public void withdraw(String acntNo, String amount) {
		dao.withdraw(acntNo, amount);
	}

	@Override
	public void fundTransfer(String sendAccNo, String recAcntNo, String amount) {
		dao.fundTransfer(sendAccNo, recAcntNo, amount);
	}

	@Override
	public void printTransaction() {
		dao.printTransaction();

	}

	@Override
	public CustomerBean customerDetails(String acntNo) {
		return dao.customerDetails(acntNo);
	}

	@Override
	public void storeInTable(String name, String mobile, String email)
			throws WalletException, SQLException {
		daoSql.storeIntoTable(name, mobile, email);
	}

}
