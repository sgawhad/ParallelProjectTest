package com.ParallelProjectTest.dao;

public interface IDao {

	void creatAccount(String name, String mobile, String email);

	boolean logIn(String acntNo);
	
	Double showBalance (String acntNo);
	
	void deposit(String acntNo,String amount);
	
	void withdraw(String acntNo,String amount);
	
	void fundTransfer(String sendAccNo,String recAcntNo, String amount);
	
	

}
