package com.ParallelProjectTest.dao;

import com.ParallelProjectTest.Exception.BalanceException;

public interface IDao {

	void creatAccount(String name, String mobile, String email);

	boolean logIn(String acntNo);
	
	Double showBalance (String acntNo);
	
	void deposit(String acntNo,String amount);
	
	void withdraw(String acntNo,String amount) throws BalanceException;
	
	void fundTransfer(String sendAccNo,String recAcntNo, String amount) throws BalanceException;
	
	String printTransaction(String acntNo);
	
	

}
